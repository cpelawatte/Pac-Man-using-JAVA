import javax.swing.JFrame;


public class App {
    public static void main(String[] args) throws Exception {

        int rowCount = 21;
        int columnCount = 19;
        int tileSize = 32;
        int boardHeight = tileSize * rowCount;
        int boardWidth = tileSize * columnCount;

        JFrame frame = new JFrame("Pac Man");
        //frame.setVisible(true);
        frame.setSize(boardWidth,boardHeight);
        frame.setLocationRelativeTo(null); //ensure that the window will be in the center
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        PacMan pacManGame = new PacMan();
        frame.add(pacManGame);
        frame.pack(); //making sure the panel fits the whole frame
        pacManGame.requestFocus();
        frame.setVisible(true);
    }
}
